
public interface Calculate {
	

	
	
	
	int add_fuction();
	int sub_function();
	int mul_function();
	double div_funciton ();

	
	
	

}

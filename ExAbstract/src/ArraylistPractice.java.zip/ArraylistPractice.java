import java.awt.List;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class ArraylistPractice {

	public static void main(String[] args) {
		ArrayList Fruitlist=new ArrayList();
		Fruitlist.add("Apple");
		Fruitlist.add("mango");
		Fruitlist.add("Banana");
		Fruitlist.add("Strawberry");
		
		
		System.out.println(Fruitlist);
		
		Fruitlist.remove(3);
		System.out.println(Fruitlist);

		
		
	}

}

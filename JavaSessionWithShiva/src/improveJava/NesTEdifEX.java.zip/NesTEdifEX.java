package improveJava;

public class NesTEdifEX {

	public static void main(String[] args) {

		int price =55000;
		
		int maxbudget=50000;
		
		if (price<=maxbudget) {
			
		int offeredPrice=45000;
		
		if (offeredPrice<=maxbudget)
			
			System.out.println("car price is in my budget");
			
		else 
				System.out.println("no the price is not in my budget");

			
		}
			
		else 
			System.out.println("the car is over my budget");
	}

}

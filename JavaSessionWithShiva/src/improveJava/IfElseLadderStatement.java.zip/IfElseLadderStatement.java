package improveJava;

public class IfElseLadderStatement {

	public static void main(String[] args) {

		
		int marks=83;
		

		if  ( marks>=90)
		System.out.println("A+Grade");
			

		else if (marks>=80)
			System.out.println("A Grade");

		else if (marks>=70)
			
		System.out.println("B Grade");


		else if (marks>=60)
			System.out.println("C Grade");


		else if (marks>=50)
			System.out.println("D Grade");



		else if (marks>=40)
			System.out.println("F Grade");

		else 
			System.out.println("The Grade is F which is failed, so Better Luck Next Time");

	
	}

}

package improveJava;

public class PracticeLocalVariable {

	public static void main(String[] args) {
		String name="Abdullah Jafori";
		int age=30;
		long mobileNumber=6468339451l;
		double salary=90000;
		boolean salFlag=true;
		
		
		System.out.println("Name: "+ name+"\n"+"Age: "+age+"\n"+"mobileNumber: "+mobileNumber+ "\n"+"salary: "+salary+"\n"+salFlag);
		
		
	}

}

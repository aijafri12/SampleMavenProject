package improveJava;

public class WhileLoopPractice {

	public static void main(String[] args) {

		

		int i =1;
		
		//example of while loop
		while(i<10) {
			
			
			System.out.println(i);
			
		i++;
		
			
		
		
		}
		
		
		
	}

}

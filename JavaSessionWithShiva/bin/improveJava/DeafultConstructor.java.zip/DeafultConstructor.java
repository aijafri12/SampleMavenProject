package improveJava;

public class DeafultConstructor {

	public DeafultConstructor() {
		System.out.println("Study more to learn Java");
			
	
		
	}
	
	
	public static void main(String[] args) {
		
		DeafultConstructor dc=new DeafultConstructor();//default constructor get executed during object creation 
		
		DeafultConstructor dc1=new DeafultConstructor();
		DeafultConstructor dc2=new DeafultConstructor();
		DeafultConstructor dc3=new DeafultConstructor();
		DeafultConstructor dc4=new DeafultConstructor();
		DeafultConstructor dc5=new DeafultConstructor();///
		

	}

}
